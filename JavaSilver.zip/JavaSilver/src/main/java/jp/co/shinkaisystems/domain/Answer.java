package jp.co.shinkaisystems.domain;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * getter/setter/引数有り無しコンストラクタ生成
 * @author ryo.shinkai
 *
 */

@Data
@AllArgsConstructor
@NoArgsConstructor
public class Answer {
	private int id; // id
	private int category_id; // カテゴリーID
	private String ans; // 答え
}
