package jp.co.shinkaisystems.form;

import lombok.Data;

@Data
public class QuestionForm {
	private int id; // ID
	private String word; // 英単語
	private String meaning; // 意味
	private int categoryid; // カテゴリ
}
