package jp.co.shinkaisystems;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class JavaSilverApplication {

    public static void main( String[] args ){
        SpringApplication.run(JavaSilverApplication.class, args);
    }
}