package jp.co.shinkaisystems.web;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.jdbc.core.namedparam.SqlParameterSource;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.SessionAttributes;

import jp.co.shinkaisystems.domain.Question;
import jp.co.shinkaisystems.form.QuestionForm;

/**
 * コントローラークラス
 * @author rksuser
 *
 */

@Controller
@SessionAttributes("all")
@RequestMapping(value="/")
public class QuestionController {
	
	@Autowired
	private NamedParameterJdbcTemplate template;
	
	private final static RowMapper<Question> questionRowMapper = (rs, i) ->{
		Integer id = rs.getInt("id");
		String word = rs.getString("word");
		String meaning = rs.getString("meaning");
		Integer categoryid = rs.getInt("categoryid");
		return new Question(id, word, meaning, categoryid);
	};
	
	@RequestMapping(value="/")
	public String index(){
		
		Model model = null;
		
		String sql = "select count(*) from words";
		
		SqlParameterSource param = new MapSqlParameterSource();
		
		List<Question> questionList = template.query(sql, questionRowMapper);
		
		int all = questionList.size();
		
		model.addAttribute("all", all);
		
		return "index";
	}
	
	@RequestMapping(value="/show", method = RequestMethod.POST)
	public String showWord(QuestionForm questionForm ,Model model){
		
	/*	
		int randomNumber = (int)Math.random();
		
		// SQL発行
		String sql = "select * from words where id = :firstId ";
		
		
		// SQLとパラメータを合わせて、三つめの引数の型で戻す。
		Integer result = template.queryForObject(sql,param,Integer.class);
		System.out.println("result = " + result);
		// MAP
		// パラメータに値を入れる
		SqlParameterSource param = new MapSqlParameterSource().addValue("firstId", 1).addValue("secondId", 3);
		
		// SQLとパラメータを合わせて、三つめの引数の型で戻す。
		Integer result = template.queryForObject(sql,param,Integer.class);
		System.out.println("result = " + result);
		
		
		
		// DBにある単語数の取得
				int length = FindWordsLogic.execute().size();

				// ランダムなIDの番号を生成
				int id = (int)(Math.random()*length+1);

				// ShowWordLogicにIDを渡して、そのIDに該当する単語を生成
				Words word = ShowWordLogic.execute(id);

				// リクエストスコープに格納
				request.setAttribute("word", word);

				// 単語を表示するページへフォワード
				RequestDispatcher rd = request.getRequestDispatcher("/jsp/showWord.jsp");
				rd.forward(request, response);
		*/
		
		return "showWord";
	}
	
}
