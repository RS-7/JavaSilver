package jp.co.shinkaisystems.domain;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * getter/setter/引数有り無しコンストラクタ生成
 * @author ryo.shinkai
 *
 */

@Data
@AllArgsConstructor
@NoArgsConstructor
public class Question {
	private int id; // ID
	private String word; // 英単語
	private String meaning; // 意味
	private int categoryid; // カテゴリ
}
